#!/bin/bash
#SBATCH --time=12:00:00
#SBATCH --partition=class
#SBATCH --mem=100G
#SBATCH --mail-user=YOUR_EMAIL_HERE
#SBATCH --mail-type=ALL
#SBATCH --ntasks=12
#SBATCH --nodes=1
#SBATCH --cpus-per-task=1
#SBATCH --job-name=fastq-dump
#SBATCH --error=download_reads.err
#SBATCH --output=download_reads.out

#Load modules
module load anaconda

#Activate conda environment
conda activate bio

#Download PacBio Reads to your scratch directory
fasterq-dump -pt /scratch/$USER/temp -e 12 DRR228447

#Deactivate conda environment
conda deactivate
