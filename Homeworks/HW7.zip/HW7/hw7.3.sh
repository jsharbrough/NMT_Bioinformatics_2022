#!/bin/bash
#SBATCH --time=1:00:00
#SBATCH --partition=class
#SBATCH --mail-user=YOUR_EMAIL_HERE
#SBATCH --mail-type=ALL
#SBATCH --mem 100G
#SBATCH --ntasks=4
#SBATCH --nodes=1
#SBATCH --cpus-per-task=1
#SBATCH --job-name=identify_mtDNA_contigs
#SBATCH --error=identify_mtDNA_contigs.err
#SBATCH --output=identify_mtDNA_contigs.out

#Load modules
module purge
module load blast-plus/2.9.0-gcc-9.2.0-5bhhtpv

#Identify mt contigs
makeblastdb -in Gasterosteus_aculeatus.BROADS1.dna.group.MT.fa -dbtype nucl -parse_seqids
blastn -db Gasterosteus_aculeatus.BROADS1.dna.group.MT.fa -query DRR228447.miniasm.fasta -evalue 0.00005 -outfmt 6 -out DRR228447.miniasm.mtDNA.BLAST.out -num_threads 4
