import sys

def gfa2Fasta(gfa):
	infile = open(gfa,'r')
	for line in infile:
		lineSplit = line.split('\t')
		if lineSplit[0] == 'S':
			sys.stdout.write('>' + lineSplit[1] + '\n' + lineSplit[2] + '\n')
	infile.close()

gfa2Fasta(sys.argv[1])
