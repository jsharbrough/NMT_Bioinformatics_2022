#!/bin/bash
#SBATCH --time=24:00:00
#SBATCH --partition=class
#SBATCH --mail-user=YOUR_EMAIL_HERE
#SBATCH --mail-type=ALL
#SBATCH --mem 100G
#SBATCH --ntasks=24
#SBATCH --nodes=1
#SBATCH --cpus-per-tas=1
#SBATCH --job-name=miniasm
#SBATCH --error=miniasm.err
#SBATCH --output=miniasm.out

#Load modules
module purge
module load anaconda

#Activate conda environment
eval "$(conda shell.bash hook)"
conda activate bio

#Map reads to themselves
minimap2 -t 24 -x ava-pb DRR228447.fastq DRR228447.fastq | gzip -c - > DRR228447.paf.gz

#Assemble reads
miniasm -f DRR228447.fastq DRR228447.paf.gz > DRR228447.miniasm.gfa

#Transform format from gfa to fasta
python gfa2Fasta.py DRR228447.miniasm.gfa > DRR228447.miniasm.fasta

conda deactivate bio
